# Pacote revisado de *gold labels* para MICA / MovieCoref

> **Versão revisada:** foram corrigidas inconsistências de coreferência de alta confiança. O original permanece em `source_annotated_original/`, e o registro completo está em `audit/coreference_review_corrections.csv`.

Este pacote foi gerado a partir dos cinco roteiros anotados no formato:

```text
[ENTIDADE|menção_no_roteiro]
```

Os arquivos foram convertidos em roteiros limpos e em CSVs compatíveis com o pré-processador do MovieCoref/MICA.

## Conteúdo

- `source_annotated/`: versão revisada das marcações.
- `source_annotated_original/`: cópia preservada antes da revisão.
- `clean_scripts/`: roteiros sem colchetes; somente o texto da menção é mantido.
- `labels_raw/`: uma linha por marcação, com texto, offsets e rótulo bruto/canônico.
- `labels_canonical/`: CSV de três colunas (`begin,end,entityLabel`) pronto para a lógica de *gold preprocessing* do MICA.
- `gold_json/`: versão auditável em JSON, com clusters e *preview* tokenizado.
- `audit/`: resumo, todas as menções, pares EN/PT e avisos/correções.
- `clean_scripts_mica_aligned/` e `labels_mica_aligned/`: cópias ajustadas para que toda menção comece e termine em fronteiras de token.
- `mica_dataset/`: layout esperado pelo pré-processamento (`movies.txt`, `parse.csv`, `screenplay/`, `labels/`), usando as cópias alinhadas.
- `code/`: scripts para converter outros roteiros e gerar `regular/*.jsonlines`.

## Convenção dos offsets

Nos CSVs de `labels_canonical/`:

- `begin`: índice de caractere iniciado em zero, inclusivo.
- `end`: índice de caractere exclusivo.
- a validação é: `script[begin:end] == mention`.

Não altere espaços, quebras de linha ou acentos no roteiro limpo depois de gerar o CSV; isso invalida offsets.

## Correções automáticas aplicadas

A marcação original continha alguns colchetes sem `|`. Foram feitas apenas correções inequívocas, registradas em `audit/*_repairs_and_brackets.csv`.

Também foram normalizados aliases evidentes no *Parasite* (por exemplo, `KI-TEK → KI_TEK`, `KI-YOO → KI_WOO`, `kitchen DA_SONG → DA_SONG`). O rótulo bruto continua disponível em `labels_raw/`.

Para o roteiro em português de *Bastardos Inglórios*, algumas menções caíam no interior de contrações (`ao`, `do`, `da`) ou tocavam palavras coladas por erro de transcrição. A cópia em `mica_dataset/` corrige apenas espaçamento e expande essas menções até fronteiras de token; as alterações estão em `audit/mica_alignment_repairs.csv`.

## Como aplicar o pré-processamento MICA

O repositório MICA recomenda a versão `regular` e exige uma tag estrutural por linha do roteiro. O arquivo `mica_dataset/parse.csv` já foi incluído, mas suas tags foram **inferidas por heurística** (cenas, falas e rubricas); antes de experimentos finais, substitua-as pela saída do Movie Screenplay Parser.

### 1. No Colab, copie o pacote e instale dependências

```bash
pip install -q spacy nltk jsonlines pandas unidecode
python -m spacy download en_core_web_sm
python -m spacy download pt_core_news_sm
```

### 2. Pré-processe os roteiros em inglês

```bash
python code/preprocess_mica_gold.py \
  --dataset_dir mica_dataset_en \
  --spacy_model en_core_web_sm \
  --output_dir mica_output_en
```

### 3. Pré-processe os roteiros em português

```bash
python code/preprocess_mica_gold.py \
  --dataset_dir mica_dataset_pt \
  --spacy_model pt_core_news_sm \
  --output_dir mica_output_pt
```

Os diretórios `mica_dataset_en/` e `mica_dataset_pt/` já estão separados por idioma e prontos para os dois comandos acima.

### 4. Se for usar o pré-processador original do repositório MICA

A estrutura de `mica_dataset_en/` e `mica_dataset_pt/` já segue a convenção de diretórios esperada:

```bash
python preprocess.py --data_dir /caminho/mica_dataset_en --gold
```

A versão original fixa `en_core_web_sm`; para português use o script deste pacote (`code/preprocess_mica_gold.py`) ou ajuste o modelo em `movie_coref/preprocess.py`.

## Separação treino / validação

O MICA coloca roteiros cujo segundo campo de `movies.txt` é `expert` na divisão `dev`. Os demais entram em `train`.

Exemplo:

```text
city_of_god_en manual
city_of_god_pt expert
```

Assim, ao reprocessar, `city_of_god_pt` será escrito em `regular/dev.jsonlines`.

## Arquivos principais

| Documento | Idioma | Roteiro limpo | CSV canônico |
|---|---|---|---|
| City of God | en | `clean_scripts/city_of_god_en_script.txt` | `labels_canonical/city_of_god_en.csv` |
| Cidade de Deus | pt | `clean_scripts/city_of_god_pt_script.txt` | `labels_canonical/city_of_god_pt.csv` |
| Parasite | en | `clean_scripts/parasite_en_script.txt` | `labels_canonical/parasite_en.csv` |
| Parasita | pt | `clean_scripts/parasite_pt_script.txt` | `labels_canonical/parasite_pt.csv` |
| Bastardos Inglórios | pt | `clean_scripts/inglourious_basterds_pt_script.txt` | `labels_canonical/inglourious_basterds_pt.csv` |

## Revisão de correferências

Consulte `audit/coreference_review_summary.md` e `audit/coreference_review_corrections.csv`. Foram registradas apenas alterações de alta confiança; casos ambíguos foram preservados para revisão humana posterior.

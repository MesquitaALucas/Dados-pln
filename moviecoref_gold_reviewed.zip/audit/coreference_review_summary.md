# Revisão de correferências — versão revisada

Foram aplicadas **64 alterações de alta confiança** ao conjunto de anotações.

## Critérios

- Corrigi somente referências cujo antecedente é inequívoco pelo contexto local (falante, interlocutor ou descrição imediata).
- Removi marcações de referentes plurais/grupais quando não representam um único personagem.
- Corrigi erros de sintaxe no formato `[ENTIDADE|menção]`.
- Mantive sem alteração os casos ambíguos, nomes de cartas/personas e referências narrativas que exigem interpretação global.

## Rastreabilidade

- `source_annotated_original/` preserva os textos antes da revisão.
- `source_annotated/` contém a versão corrigida.
- `audit/coreference_review_corrections.csv` lista cada alteração, a linha, o motivo e a confiança.
- Todos os CSVs, JSONs e diretórios `mica_dataset*` foram regenerados a partir da versão corrigida.

## Observação metodológica

Esta é uma revisão de consistência **de alta confiança**, não uma nova anotação independente e exaustiva de cada menção. Para estabelecer um gold final de avaliação, recomenda-se uma segunda revisão humana cega, seguida de adjudicação das divergências.

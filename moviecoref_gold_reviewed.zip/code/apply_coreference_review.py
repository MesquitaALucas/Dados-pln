#!/usr/bin/env python3
"""
This package was created with a controlled correction manifest.
The immutable before/after audit is in ../audit/coreference_review_corrections.csv.
For reproducible downstream conversion, run:
    python convert_annotations.py INPUT.txt OUTPUT_SCRIPT.txt OUTPUT_LABELS.csv
Then run preprocess_mica_gold.py on mica_dataset_en or mica_dataset_pt.
"""
print("See audit/coreference_review_corrections.csv for the reviewed correction manifest.")

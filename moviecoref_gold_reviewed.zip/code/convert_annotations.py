#!/usr/bin/env python3
"""
Reusable converter for annotations formatted as [ENTITY|MENTION].

Usage:
  python convert_annotations.py INPUT.txt OUTPUT_SCRIPT.txt OUTPUT_LABELS.csv

It preserves the surface text of each mention, removes annotation brackets,
and writes MICA-compatible fields: begin,end,entityLabel.
"""
from __future__ import annotations
import argparse, csv, re
from pathlib import Path

ANNOT_RE = re.compile(r"\[([^|\]\n]+)\|([^\]\n]+)\]")

def convert(source: Path, output_script: Path, output_labels: Path) -> None:
    text = source.read_text(encoding="utf-8")
    parts, rows = [], []
    last = 0
    for mention_id, match in enumerate(ANNOT_RE.finditer(text)):
        parts.append(text[last:match.start()])
        label, surface = match.group(1).strip(), match.group(2)
        begin = sum(map(len, parts))
        parts.append(surface)
        end = begin + len(surface)
        rows.append({"begin": begin, "end": end, "entityLabel": label, "_surface": surface})
        last = match.end()
    parts.append(text[last:])
    clean = "".join(parts)

    for row in rows:
        assert clean[row["begin"]:row["end"]] == row["_surface"], row

    output_script.parent.mkdir(parents=True, exist_ok=True)
    output_labels.parent.mkdir(parents=True, exist_ok=True)
    output_script.write_text(clean, encoding="utf-8")
    with output_labels.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["begin", "end", "entityLabel"])
        w.writeheader()
        for row in rows:
            w.writerow({key: row[key] for key in ("begin", "end", "entityLabel")})

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output_script")
    ap.add_argument("output_labels")
    args = ap.parse_args()
    convert(Path(args.input), Path(args.output_script), Path(args.output_labels))

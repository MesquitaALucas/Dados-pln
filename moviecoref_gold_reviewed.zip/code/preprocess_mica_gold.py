#!/usr/bin/env python3
"""
Multilingual gold preprocessor for a MICA/MovieCoref-style dataset.

Inputs (dataset directory):
  movies.txt                  '<movie> <rater>' per line
  parse.csv                   columns: movie,robust (one row per script line)
  screenplay/<movie>.txt      clean screenplay
  labels/<movie>.csv          begin,end,entityLabel

Output:
  regular/all.jsonlines
  regular/train.jsonlines     rater != expert
  regular/dev.jsonlines       rater == expert

It mirrors the relevant offset logic in USC-SAIL's MovieCoref preprocessor,
but lets you choose a spaCy model. Use:
  en_core_web_sm for English
  pt_core_news_sm for Portuguese

Important: `parse.csv` in this package is heuristic. Replace it with the
Movie Screenplay Parser output before final experiments.
"""
from __future__ import annotations
import argparse, csv, json, re
from collections import defaultdict
from pathlib import Path
import nltk
from nltk.tokenize import wordpunct_tokenize
import spacy
from unidecode import unidecode

def nwlen(text: str) -> int:
    return len(re.sub(r"\s+", "", text))

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset_dir", required=True)
    ap.add_argument("--spacy_model", required=True)
    ap.add_argument("--output_dir", default=None)
    args = ap.parse_args()

    root = Path(args.dataset_dir)
    out = Path(args.output_dir) if args.output_dir else root / "regular"
    out.mkdir(parents=True, exist_ok=True)

    nlp = spacy.load(args.spacy_model)
    parse_rows = list(csv.DictReader((root / "parse.csv").open(encoding="utf-8")))
    parses = defaultdict(list)
    for row in parse_rows:
        parses[row["movie"]].append(row["robust"])

    movies = []
    for line in (root / "movies.txt").read_text(encoding="utf-8").splitlines():
        if line.strip():
            movie, rater = line.split(maxsplit=1)
            movies.append((movie, rater))

    all_docs = []
    for movie, rater in movies:
        script = (root / "screenplay" / f"{movie}.txt").read_text(encoding="utf-8")
        lines = script.splitlines()
        tags = parses[movie]
        if len(lines) != len(tags):
            raise ValueError(f"{movie}: {len(lines)} script lines != {len(tags)} parse tags")
        mentions = list(csv.DictReader((root / "labels" / f"{movie}.csv").open(encoding="utf-8-sig")))
        mentions = sorted(
            [(int(x["begin"]), int(x["end"]), x["entityLabel"]) for x in mentions],
            key=lambda x: (x[0], x[1], x[2])
        )

        # Character offsets with whitespace removed, exactly like MICA.
        char_mentions = []
        prev_begin = prev_wsbegin = 0
        for i, (begin, end, entity) in enumerate(mentions):
            wsbegin = nwlen(script[:begin]) if i == 0 else prev_wsbegin + nwlen(script[prev_begin:begin])
            wsend = wsbegin + nwlen(script[begin:end])
            prev_begin, prev_wsbegin = begin, wsbegin
            char_mentions.append((wsbegin, wsend, begin, end, entity))

        # Group adjacent script lines that share the same structural tag.
        segment_texts, segment_tags = [], []
        i = 0
        while i < len(lines):
            j = i + 1
            while j < len(lines) and tags[j] == tags[i]:
                j += 1
            segment = re.sub(r"\s+", " ", " ".join(lines[i:j]).strip())
            segment = " ".join(wordpunct_tokenize(segment)).strip()
            if segment:
                segment_texts.append(segment)
                segment_tags.append(tags[i])
            i = j

        tokens, token_heads, token_begins, token_ends = [], [], [], []
        postags, nertags, token_tags, token_sentids = [], [], [], []
        c = s = n = 0
        for si, doc in enumerate(nlp.pipe(segment_texts, batch_size=512)):
            for sent in doc.sents:
                for tok in sent:
                    text = tok.text
                    tokens.append(unidecode(text).strip())
                    token_heads.append(n + tok.head.i)
                    token_begins.append(c)
                    c += nwlen(text)
                    token_ends.append(c)
                    postags.append(tok.tag_)
                    nertags.append(tok.ent_type_ or "-")
                    token_tags.append(segment_tags[si])
                    token_sentids.append(s)
                n += len(sent)
                s += 1

        clusters = defaultdict(list)
        missed = []
        for wsbegin, wsend, begin, end, entity in char_mentions:
            try:
                mbegin = token_begins.index(wsbegin)
                mend = token_ends.index(wsend)
            except ValueError:
                missed.append({"entity": entity, "text": script[begin:end], "begin": begin, "end": end})
                continue
            candidate_heads = []
            for idx in range(mbegin, mend + 1):
                head = token_heads[idx]
                if head == idx or head < mbegin or head > mend:
                    candidate_heads.append(idx)
            mhead = candidate_heads[0] if len(candidate_heads) == 1 else mend
            clusters[entity].append([mbegin, mend, mhead])

        speakers = ["-"] * len(tokens)
        i = 0
        while i < len(tokens):
            if token_tags[i] == "C":
                j = i + 1
                while j < len(tokens) and token_tags[j] == "C":
                    j += 1
                k = j
                utterance = []
                while k < len(tokens) and token_tags[k] not in ("S", "C"):
                    if token_tags[k] in ("D", "E"):
                        utterance.append(k)
                    k += 1
                if utterance:
                    speaker = re.sub(r"\([^)]*\)", "", " ".join(tokens[i:j])).strip() or " ".join(tokens[i:j])
                    for u in utterance:
                        speakers[u] = speaker
                i = k
            else:
                i += 1

        sent_offset = []
        i = 0
        while i < len(token_sentids):
            j = i + 1
            while j < len(token_sentids) and token_sentids[j] == token_sentids[i]:
                j += 1
            sent_offset.append([i, j - 1])
            i = j

        output = {
            "movie": movie,
            "rater": rater,
            "token": tokens,
            "pos": postags,
            "ner": nertags,
            "parse": token_tags,
            "speaker": speakers,
            "sent_offset": sent_offset,
            "clusters": dict(clusters),
            "unmapped_mentions": missed,
        }
        all_docs.append(output)
        print(f"{movie}: {len(tokens)} tokens, {sum(map(len, clusters.values()))} mapped mentions, {len(missed)} unmapped")

    def dump(name, docs):
        with (out / name).open("w", encoding="utf-8") as f:
            for doc in docs:
                f.write(json.dumps(doc, ensure_ascii=False) + "\n")
    dump("all.jsonlines", all_docs)
    dump("train.jsonlines", [d for d in all_docs if d["rater"] != "expert"])
    dump("dev.jsonlines", [d for d in all_docs if d["rater"] == "expert"])

if __name__ == "__main__":
    main()
